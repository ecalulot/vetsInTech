y = input("What is your name? ")
print("Hello " + y + "!")
print("I hope you enjoy this course!")