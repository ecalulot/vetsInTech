# ITP Week 1 Day 1 Exercise

# declare a VARIABLE named my_favorite_band and ASSIGN it a STRING value of your choice.



# PRINT a CONCATENATION of the variable and a string literal: " is my favorite band!"



# prompt an user INPUT to ask "What is your favorite color?" and assign it to a variable called "user_favorite_color"



# PRINT a string concatenation with user_favorite_color and "is a nice color!"


