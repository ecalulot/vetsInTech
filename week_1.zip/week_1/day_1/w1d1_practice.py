# ITP Week 1 Day 1 (In-Class) Practice

# First run this file to see what the expected output is for the following questions.

print('      /|')
print('     / |')
print('    /  |')
print('   /___|')

# recreate this triangle with a height of 6

# recreate the 4 level triangle with a single line using \n

# recreate the 4 level triangle using a multi-line string
