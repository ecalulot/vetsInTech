# ITP Week 1 Day 2 (In-Class) Practice

# a. assign a variable 'subtotal' to 17.75

# b. assign a variable 'tax_percentage' to .18

# c. assign a variable 'tax_amount' to the product of subtotal and tax_percentage 

# d. assign a variable 'total' to the sum of subtotal and tax_amount
