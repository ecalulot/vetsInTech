# ITP Week 2 Day 1 (In-Class) Practice

# A1. from the appropriate library, import only the Workbook

# A2. Before anything, we need a workbook to work with..

# A3. We need to interact with a single worksheet.

# A4. assign the value of "First Name" to A1

# A5. assign the value of "Last Name" to B1

# STOP HERE - RETURN TO LECTURE

# B1. For all of column A, starting at row 2 until row 10, make the cell values: "Gabriel" (attempt a loop)



last_names = ['Rolley', 'Smith', 'Balenga', 'Issac', 'Cruise', 'Depp', 'Heard', 'Qiao', 'Biden']

# B2. Loop through a range from row 2 to 10 and assign the cell value to last names according to index in column B
# NOTE: PAY ATTENTION to the starting number of the range and how it differs from the starting index of the list

# B3. Save the file
# wb.save("./spreadsheets/day_1_practice.xlsx")