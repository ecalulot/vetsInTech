# ITP Week 2 Day 2 (In-Class) Practice 2

# Creating and Calling Functions

# Create a function called greetings that prints "Hello World!"

# Call greetings and run this Python file


# Create a function called add_num: 

# Inside your function define two variables: x and y, assign 5 to x and 7 to y
# print the sum of x and y

# Call your function


# Create a function called subtract_num:

# Inside your function define two variables: x and y, assign 10 to x and 3 to y
# print the difference of x and y

# Call your function

# Create a function called multiply_num:

# Inside your function define two variables: x and y, assign 5 to x and 7 to y
# print the product of x and y

# Call your function


# Create a function called divide_num:

# Inside your function define two variables: x and y, assign 10 to x and 2 to y
# print the quotient of x divided by y

# Call your function
