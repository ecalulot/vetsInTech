# ITP Week 3 Day 1 Practice

# import your required modules/methods

# given the following items, using the methods we covered, write to openpyxl

# use an external counter with just a for loop (no function)
clefairy = {
    "id": 35,
    "name": "clefairy",
    "base_experience": 113,
    "height": 6,
    "order": 56,
    "weight": 75,
}


# create a function that takes in a pokemon
weedle = {
    "id": 13,
    "name": "weedle",
    "base_experience": 39,
    "height": 3,
    "order": 17,
    "weight": 32
}

# call the function with weedle!


# wb.save('./spreadsheets/practice.xlsx')