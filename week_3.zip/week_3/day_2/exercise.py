# ITP Week 3 Day 2 Exercise

# import in the two modules for making API calls and parsing the data

# set a url variable to "https://rickandmortyapi.com/api/character"

# set a variable response to the "get" request of the url

# print to verify we have a status code of 200

# assign a variable json_data to the responses' json

# print to verify a crazy body of strings!

# lets make it into a python dictionary by using the appropriate json method

# print the newly created python object
